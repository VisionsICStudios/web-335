#
#============================================
# Title:  wilsonA-calculator.py 
# Author: Professor Krasso
# Modified By: Aaron Wilson
# Date: 21 June 2019
# Description: Performs calculations (Python)
#===========================================
#

def add(sum1, sum2):
    return sum1 + sum2

def subtract(sum1, sum2):
    return sum1 - sum2
    
def divide(sum1, sum2):
    return sum1 / sum2

print(add(1, 2)) 
print(subtract(4, 1))
print(divide(8, 2))  